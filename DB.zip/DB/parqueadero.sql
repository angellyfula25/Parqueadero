-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-06-2022 a las 07:00:52
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `parqueadero`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `doc` varchar(20) CHARACTER SET utf8 NOT NULL,
  `tipo_doc` varchar(4) CHARACTER SET utf8 NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 NOT NULL,
  `celular` varchar(15) CHARACTER SET utf8 NOT NULL,
  `correo` varchar(30) CHARACTER SET utf8 NOT NULL,
  `contraseña` varchar(10) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `celdas`
--

CREATE TABLE `celdas` (
  `id_celdas` int(8) NOT NULL,
  `ubicacion` varchar(2) CHARACTER SET utf8 NOT NULL,
  `descripcion` varchar(20) CHARACTER SET utf8 NOT NULL,
  `estado` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `doc` varchar(20) CHARACTER SET utf8 NOT NULL,
  `tipo_doc` varchar(4) CHARACTER SET utf8 NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 NOT NULL,
  `domicilio` varchar(30) CHARACTER SET utf8 NOT NULL,
  `correo` varchar(30) CHARACTER SET utf8 NOT NULL,
  `celular` varchar(15) CHARACTER SET utf8 NOT NULL,
  `doc_empleado` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `doc` varchar(20) CHARACTER SET utf8 NOT NULL,
  `tipo_doc` varchar(4) CHARACTER SET utf8 NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf32 NOT NULL,
  `celular` varchar(15) CHARACTER SET utf8 NOT NULL,
  `correo` varchar(30) NOT NULL,
  `contraseña` varchar(10) CHARACTER SET utf8 NOT NULL,
  `doc_administrador` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `num_doc` varchar(20) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(10) CHARACTER SET utf16 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id_pagos` int(5) NOT NULL,
  `fechayhora` date NOT NULL,
  `concepto` varchar(30) CHARACTER SET utf8 NOT NULL,
  `placa_vehiculo` varchar(6) CHARACTER SET utf8 NOT NULL,
  `doc_empleado` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `id` int(5) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_salida` date NOT NULL,
  `placa_vehiculo` varchar(6) CHARACTER SET utf8 NOT NULL,
  `celdas_id` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `id` int(5) NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8 NOT NULL,
  `placa_vehiculo` varchar(6) CHARACTER SET utf8 NOT NULL,
  `id_pagos` int(5) NOT NULL,
  `id_celdas` int(8) NOT NULL,
  `doc_administrador` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `placa` varchar(6) CHARACTER SET utf8 NOT NULL,
  `tipo_vehiculo` varchar(15) CHARACTER SET utf8 NOT NULL,
  `categoria` varchar(15) CHARACTER SET utf8 NOT NULL,
  `descripcion` varchar(30) CHARACTER SET utf8 NOT NULL,
  `imagen` text CHARACTER SET utf8 NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `novedades` varchar(50) CHARACTER SET utf8 NOT NULL,
  `doc_cliente` varchar(20) CHARACTER SET utf8 NOT NULL,
  `id_pagos` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`doc`),
  ADD KEY `doc` (`doc`);

--
-- Indices de la tabla `celdas`
--
ALTER TABLE `celdas`
  ADD PRIMARY KEY (`id_celdas`),
  ADD KEY `id_celdas` (`id_celdas`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`doc`),
  ADD KEY `doc_empleado` (`doc_empleado`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`doc`),
  ADD KEY `doc` (`doc`),
  ADD KEY `id_administrador` (`doc_administrador`);

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`num_doc`),
  ADD KEY `num_doc` (`num_doc`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pagos`),
  ADD KEY `placa_vehiculo` (`placa_vehiculo`,`doc_empleado`),
  ADD KEY `doc_empleado` (`doc_empleado`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `celdas_id` (`celdas_id`),
  ADD KEY `placa_vehiculo` (`placa_vehiculo`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`placa_vehiculo`,`id_pagos`,`id_celdas`,`doc_administrador`),
  ADD KEY `doc_administrador` (`doc_administrador`),
  ADD KEY `id_celdas` (`id_celdas`),
  ADD KEY `id_pagos` (`id_pagos`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`placa`),
  ADD KEY `placa` (`placa`),
  ADD KEY `doc_cliente` (`doc_cliente`,`id_pagos`),
  ADD KEY `id_pagos` (`id_pagos`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id_pagos` int(5) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD CONSTRAINT `administrador_ibfk_1` FOREIGN KEY (`doc`) REFERENCES `login` (`num_doc`);

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`doc_empleado`) REFERENCES `empleado` (`doc`);

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`doc`) REFERENCES `login` (`num_doc`),
  ADD CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`doc_administrador`) REFERENCES `administrador` (`doc`);

--
-- Filtros para la tabla `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`num_doc`) REFERENCES `cliente` (`doc`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`placa_vehiculo`) REFERENCES `vehiculo` (`placa`),
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`doc_empleado`) REFERENCES `empleado` (`doc`);

--
-- Filtros para la tabla `registro`
--
ALTER TABLE `registro`
  ADD CONSTRAINT `registro_ibfk_1` FOREIGN KEY (`celdas_id`) REFERENCES `celdas` (`id_celdas`),
  ADD CONSTRAINT `registro_ibfk_2` FOREIGN KEY (`placa_vehiculo`) REFERENCES `vehiculo` (`placa`);

--
-- Filtros para la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD CONSTRAINT `reportes_ibfk_1` FOREIGN KEY (`doc_administrador`) REFERENCES `administrador` (`doc`),
  ADD CONSTRAINT `reportes_ibfk_2` FOREIGN KEY (`id_celdas`) REFERENCES `celdas` (`id_celdas`),
  ADD CONSTRAINT `reportes_ibfk_3` FOREIGN KEY (`id_pagos`) REFERENCES `pagos` (`id_pagos`);

--
-- Filtros para la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD CONSTRAINT `vehiculo_ibfk_1` FOREIGN KEY (`doc_cliente`) REFERENCES `cliente` (`doc`),
  ADD CONSTRAINT `vehiculo_ibfk_2` FOREIGN KEY (`id_pagos`) REFERENCES `pagos` (`id_pagos`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
